"""
Name: Russell Harvey
RIT: rdh1896
"""

import subprocess
import os
import threading

def worker(thread):
    """
    Function that main calls to run and fork processes
    """

    username = subprocess.check_output("whoami", shell = True)
    #print("Executing thread.")
    orig_pid = os.getpid()
    #print("PID identified. {}".format(os.getpid()))
    pid = os.fork()
    if pid == 0:
        new_pid = os.getpid()
    else:
        new_pid = "In original process."
    print(f"Thread ID: {thread} - Original PID: {orig_pid} - User: {username} - New PID: {new_pid}")

    '''
    if pid == 0:
        #In new process
        print("New process identified.")
        print("PID identified. {}".format(os.getpid()))
    else:
        #In original process
        print("Original process identified.")
        print("PID identified. {}".format(os.getpid()))
    '''

def main():
    """
    Runs processes and prints out information about them.
    """
    threads = input("# of Threads?: ")
    print("Main Executing.")
    print("PID identified. {}".format(os.getpid()))
    for i in range(0, int(threads)):
        t = threading.Thread(target=worker(i))
        t.start()

        
main()
