"""
Name: Russell Harvey <rdh1896@rit.edu>
Assignment: Lab 01 Part1B

Explanation: The deadlock would occur when one lock was locked by one thread
and the other was locked by the other thread. Both threads would attempt to acquire
the other lock and they would be stuck waiting for the lock to come undone.
"""

import threading
x = 0

def task(lock1, lock2, count):
    global x
    for i in range (count):
        lock1.acquire()
        while lock2.locked():
            lock1.release()
            lock1.acquire()
        lock2.acquire()
        x+=1
        lock1.release()
        lock2.release()

def main():
    global x
    count = 1000000
    lock1 = threading.Lock()
    lock2 = threading.Lock()
    T1 = threading.Thread(target = task, args = (lock1, lock2, count))
    T2 = threading.Thread(target = task, args = (lock2, lock1, count))
    T1.start()
    T2.start()
    T1.join()
    T2.join()
    print(f"x = {x}")

main()