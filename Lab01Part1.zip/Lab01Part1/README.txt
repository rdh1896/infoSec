Professor Olson,

I attempted to email you regarding the way you wanted the lab turned in but have had no response as of
6:18pm. So I have uploaded 2 python files, one is the original we coded in class, "Lab01Part1Orig.py",
and the other is an updated version trying to accomplish what was asked on the Lab 01 instructions,
"Lab01Part1New.py". Grade which ever one you were looking for. Thanks much!

Sincerely,
Russell Harvey
rdh1896